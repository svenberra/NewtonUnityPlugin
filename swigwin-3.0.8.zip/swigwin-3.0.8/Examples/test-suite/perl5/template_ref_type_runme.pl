use template_ref_type;

my $xr = template_ref_type::XC->new();
my $y = template_ref_type::Y->new();

$y->find($xr);
