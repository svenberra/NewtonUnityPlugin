
int multiply20(int a);

#define PREPROC_INCLUDE_C "preproc_include_c.h"

#include PREPROC_INCLUDE_C

